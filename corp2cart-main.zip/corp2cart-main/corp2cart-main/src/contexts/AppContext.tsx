import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'farmer' | 'consumer' | 'admin';

export interface Product {
  id: string;
  name: string;
  category: string;
  image: string;
  price: number;
  unit: string;
  quantity: number;
  farmerId: string;
  farmerName: string;
  farmerLocation: string;
  farmerContact: string;
  status: 'approved' | 'pending' | 'rejected';
  farmerVerified?: boolean;
  farmerRating?: number;
  harvestedToday?: boolean;
}

export interface CartItem {
  product: Product;
  qty: number;
}

export type DeliverySlot = 'morning' | 'afternoon' | 'evening';

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: 'placed' | 'confirmed' | 'shipped' | 'delivered';
  paymentMethod: 'online' | 'cod';
  date: string;
  buyerName?: string;
  deliverySlot?: DeliverySlot;
  farmerAccepted?: boolean;
}

export interface Notification {
  id: string;
  message: string;
  orderId: string;
  read: boolean;
  timestamp: string;
}

interface AppState {
  role: UserRole | null;
  setRole: (r: UserRole | null) => void;
  isLoggedIn: boolean;
  setIsLoggedIn: (v: boolean) => void;
  userName: string;
  setUserName: (n: string) => void;
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  cart: CartItem[];
  addToCart: (p: Product) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  orders: Order[];
  addOrder: (o: Order) => void;
  updateOrderStatus: (id: string, status: Order['status'], farmerAccepted?: boolean) => void;
  notifications: Notification[];
  markNotificationRead: (id: string) => void;
  unreadCount: number;
  wishlist: string[];
  toggleWishlist: (id: string) => void;
}

const sampleProducts: Product[] = [
  { id: '1', name: 'Tomatoes', category: 'vegetables', image: '🍅', price: 40, unit: 'kg', quantity: 50, farmerId: 'f1', farmerName: 'Raju', farmerLocation: 'Anantapur', farmerContact: '9876543210', status: 'approved', farmerVerified: true, farmerRating: 4.5, harvestedToday: true },
  { id: '2', name: 'Mangoes', category: 'fruits', image: '🥭', price: 120, unit: 'kg', quantity: 30, farmerId: 'f1', farmerName: 'Raju', farmerLocation: 'Anantapur', farmerContact: '9876543210', status: 'approved', farmerVerified: true, farmerRating: 4.5 },
  { id: '3', name: 'Rice', category: 'grains', image: '🌾', price: 60, unit: 'kg', quantity: 200, farmerId: 'f2', farmerName: 'Lakshmi', farmerLocation: 'Warangal', farmerContact: '9876543211', status: 'approved', farmerVerified: true, farmerRating: 4.8 },
  { id: '4', name: 'Milk', category: 'dairy', image: '🥛', price: 55, unit: 'litre', quantity: 100, farmerId: 'f2', farmerName: 'Lakshmi', farmerLocation: 'Warangal', farmerContact: '9876543211', status: 'approved', farmerVerified: true, farmerRating: 4.8, harvestedToday: true },
  { id: '5', name: 'Eggs', category: 'poultry', image: '🥚', price: 6, unit: 'piece', quantity: 0, farmerId: 'f3', farmerName: 'Suresh', farmerLocation: 'Guntur', farmerContact: '9876543212', status: 'approved', farmerVerified: false, farmerRating: 4.2 },
  { id: '6', name: 'Onions', category: 'vegetables', image: '🧅', price: 30, unit: 'kg', quantity: 8, farmerId: 'f3', farmerName: 'Suresh', farmerLocation: 'Guntur', farmerContact: '9876543212', status: 'approved', farmerVerified: true, farmerRating: 4.2, harvestedToday: true },
  { id: '7', name: 'Bananas', category: 'fruits', image: '🍌', price: 50, unit: 'kg', quantity: 60, farmerId: 'f1', farmerName: 'Raju', farmerLocation: 'Anantapur', farmerContact: '9876543210', status: 'approved', farmerVerified: true, farmerRating: 4.5 },
  { id: '8', name: 'Paneer', category: 'dairy', image: '🧀', price: 320, unit: 'kg', quantity: 20, farmerId: 'f2', farmerName: 'Lakshmi', farmerLocation: 'Warangal', farmerContact: '9876543211', status: 'approved', farmerVerified: true, farmerRating: 4.8 },
  { id: '9', name: 'Chicken', category: 'poultry', image: '🍗', price: 220, unit: 'kg', quantity: 40, farmerId: 'f3', farmerName: 'Suresh', farmerLocation: 'Guntur', farmerContact: '9876543212', status: 'pending', farmerVerified: false, farmerRating: 4.2 },
  { id: '10', name: 'Wheat', category: 'grains', image: '🌿', price: 45, unit: 'kg', quantity: 150, farmerId: 'f1', farmerName: 'Raju', farmerLocation: 'Anantapur', farmerContact: '9876543210', status: 'approved', farmerVerified: true, farmerRating: 4.5 },
  { id: '11', name: 'Curd', category: 'dairy', image: '🍶', price: 50, unit: 'litre', quantity: 40, farmerId: 'f2', farmerName: 'Lakshmi', farmerLocation: 'Warangal', farmerContact: '9876543211', status: 'approved', farmerVerified: true, farmerRating: 4.8 },
  { id: '12', name: 'Potatoes', category: 'vegetables', image: '🥔', price: 25, unit: 'kg', quantity: 100, farmerId: 'f1', farmerName: 'Raju', farmerLocation: 'Anantapur', farmerContact: '9876543210', status: 'approved', farmerVerified: true, farmerRating: 4.5 },
];

const AppContext = createContext<AppState | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [role, setRole] = useState<UserRole | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState('');
  const [products, setProducts] = useState<Product[]>(sampleProducts);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const addToCart = (p: Product) => {
    if (p.quantity <= 0) return;
    setCart(prev => {
      const existing = prev.find(c => c.product.id === p.id);
      if (existing) return prev.map(c => c.product.id === p.id ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, { product: p, qty: 1 }];
    });
  };

  const removeFromCart = (id: string) => setCart(prev => prev.filter(c => c.product.id !== id));
  const clearCart = () => setCart([]);

  const addOrder = (o: Order) => {
    setOrders(prev => [o, ...prev]);
    // Generate notifications for farmers
    const farmerItems = new Map<string, string[]>();
    o.items.forEach(item => {
      const key = item.product.farmerId;
      if (!farmerItems.has(key)) farmerItems.set(key, []);
      farmerItems.get(key)!.push(`${item.qty}${item.product.unit} ${item.product.name}`);
    });
    farmerItems.forEach((items, farmerId) => {
      const notification: Notification = {
        id: `n-${Date.now()}-${farmerId}`,
        message: `New order received for ${items.join(', ')} from ${o.buyerName || 'Customer'}`,
        orderId: o.id,
        read: false,
        timestamp: new Date().toLocaleTimeString(),
      };
      setNotifications(prev => [notification, ...prev]);
    });
  };

  const updateOrderStatus = (id: string, status: Order['status'], farmerAccepted?: boolean) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status, ...(farmerAccepted !== undefined ? { farmerAccepted } : {}) } : o));
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const toggleWishlist = (id: string) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  return (
    <AppContext.Provider value={{ role, setRole, isLoggedIn, setIsLoggedIn, userName, setUserName, products, setProducts, cart, addToCart, removeFromCart, clearCart, orders, addOrder, updateOrderStatus, notifications, markNotificationRead, unreadCount, wishlist, toggleWishlist }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
