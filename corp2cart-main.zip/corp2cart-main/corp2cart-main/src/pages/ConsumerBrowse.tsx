import { useState, useRef } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import { useNavigate } from 'react-router-dom';
import BottomNav from '@/components/BottomNav';
import TopNav from '@/components/TopNav';
import HeroSection from '@/components/HeroSection';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Star, MapPin, Phone, ShoppingCart, CheckCircle2, Leaf, AlertTriangle, Heart, ArrowUpDown } from 'lucide-react';
import { toast } from 'sonner';

const categories = [
  { key: 'all', emoji: '🛒' },
  { key: 'vegetables', emoji: '🥬' },
  { key: 'fruits', emoji: '🍎' },
  { key: 'grains', emoji: '🌾' },
  { key: 'dairy', emoji: '🥛' },
  { key: 'poultry', emoji: '🥚' },
];

type SortOption = 'default' | 'price-asc' | 'price-desc' | 'rating';

const ConsumerBrowse = () => {
  const { t } = useLanguage();
  const { products, addToCart, cart, wishlist, toggleWishlist } = useApp();
  const navigate = useNavigate();
  const [selectedCat, setSelectedCat] = useState('all');
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('default');
  const productsRef = useRef<HTMLDivElement>(null);

  const approvedProducts = products.filter(p => p.status === 'approved');
  let filtered = approvedProducts
    .filter(p => selectedCat === 'all' || p.category === selectedCat)
    .filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  // Sort
  if (sortBy === 'price-asc') filtered = [...filtered].sort((a, b) => a.price - b.price);
  else if (sortBy === 'price-desc') filtered = [...filtered].sort((a, b) => b.price - a.price);
  else if (sortBy === 'rating') filtered = [...filtered].sort((a, b) => (b.farmerRating || 0) - (a.farmerRating || 0));

  const cartCount = cart.reduce((s, c) => s + c.qty, 0);

  const getStockLabel = (p: typeof products[0]) => {
    if (p.quantity <= 0) return { text: t('outOfStock'), color: 'text-destructive', urgent: true };
    if (p.quantity <= 10) return { text: t('onlyLeft').replace('{qty}', String(p.quantity)).replace('{unit}', p.unit), color: 'text-secondary', urgent: true };
    return { text: `${p.quantity} ${t('available')}`, color: 'text-muted-foreground', urgent: false };
  };

  const scrollToProducts = () => {
    productsRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <TopNav role="consumer" search={search} onSearchChange={setSearch} />

      {/* Hero - desktop & mobile */}
      <HeroSection
        onShopNow={scrollToProducts}
        onBecomeFarmer={() => navigate('/')}
      />

      {/* Mobile Header */}
      <div className="md:hidden bg-primary text-primary-foreground p-6 pb-10 rounded-b-3xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm opacity-80">🌿 Crop2Cart</p>
            <h1 className="text-xl font-bold" style={{ fontFamily: 'Poppins' }}>{t('tagline')}</h1>
          </div>
          <button onClick={() => navigate('/consumer/cart')} className="relative">
            <ShoppingCart className="w-6 h-6" />
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 w-5 h-5 bg-secondary text-secondary-foreground text-xs font-bold rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder={t('search')}
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-10 h-12 bg-card text-foreground border-0"
          />
        </div>
      </div>

      <div ref={productsRef} className="max-w-7xl mx-auto">
        {/* Categories */}
        <div className="flex gap-2 px-4 md:px-6 -mt-5 md:mt-6 overflow-x-auto pb-2">
          {categories.map(c => (
            <button
              key={c.key}
              onClick={() => setSelectedCat(c.key)}
              className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedCat === c.key
                  ? 'bg-primary text-primary-foreground shadow-md'
                  : 'bg-card text-foreground border hover:border-primary/40'
              }`}
            >
              {c.emoji} {c.key === 'all' ? t('allCategories') : t(c.key)}
            </button>
          ))}
        </div>

        {/* Sort bar - desktop */}
        <div className="hidden md:flex items-center justify-between px-6 mt-6">
          <h2 className="text-xl font-bold text-foreground" style={{ fontFamily: 'Poppins' }}>
            {t('featuredProducts')} ({filtered.length})
          </h2>
          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-4 h-4 text-muted-foreground" />
            <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
              <SelectTrigger className="w-48 h-9 text-sm border-0 bg-muted/50">
                <SelectValue placeholder={t('sortBy')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">{t('sortBy')}</SelectItem>
                <SelectItem value="price-asc">{t('priceLowHigh')}</SelectItem>
                <SelectItem value="price-desc">{t('priceHighLow')}</SelectItem>
                <SelectItem value="rating">{t('rating')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Products grid - responsive */}
        <div className="px-4 md:px-6 mt-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
          {filtered.map((p, i) => {
            const stock = getStockLabel(p);
            const isOutOfStock = p.quantity <= 0;
            const isWishlisted = wishlist.includes(p.id);
            return (
              <div
                key={p.id}
                className={`bg-card rounded-xl border overflow-hidden animate-fade-in group transition-all duration-200 hover:shadow-lg hover:border-primary/20 ${isOutOfStock ? 'opacity-60' : ''}`}
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                <div className="h-24 md:h-36 bg-accent flex items-center justify-center text-5xl md:text-7xl relative">
                  {p.image}
                  {/* Wishlist heart */}
                  <button
                    onClick={() => toggleWishlist(p.id)}
                    className="absolute top-2 right-2 w-8 h-8 rounded-full bg-card/80 backdrop-blur-sm flex items-center justify-center transition-all hover:scale-110"
                  >
                    <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-destructive text-destructive' : 'text-muted-foreground'}`} />
                  </button>
                  {p.harvestedToday && (
                    <span className="absolute top-2 left-2 bg-primary text-primary-foreground text-[9px] md:text-xs px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                      <Leaf className="w-2.5 h-2.5 md:w-3 md:h-3" /> Fresh
                    </span>
                  )}
                  {isOutOfStock && (
                    <div className="absolute inset-0 bg-background/50 flex items-center justify-center">
                      <span className="bg-destructive text-destructive-foreground text-xs font-bold px-2 py-1 rounded">{t('outOfStock')}</span>
                    </div>
                  )}
                </div>
                <div className="p-3 md:p-4">
                  <h3 className="font-semibold text-foreground text-sm md:text-base">{p.name}</h3>
                  <p className="text-lg md:text-xl font-bold text-primary">₹{p.price}<span className="text-xs text-muted-foreground font-normal">/{p.unit}</span></p>

                  {/* Stock indicator */}
                  <p className={`text-xs font-medium ${stock.color} flex items-center gap-1`}>
                    {stock.urgent && <AlertTriangle className="w-3 h-3" />}
                    {stock.text}
                  </p>
                  {p.harvestedToday && !isOutOfStock && (
                    <p className="text-[10px] text-primary font-medium flex items-center gap-1 mt-0.5">
                      <Leaf className="w-3 h-3" /> {t('freshToday')}
                    </p>
                  )}

                  {/* Farmer info */}
                  <div className="flex items-center gap-1 mt-1.5">
                    <Star className="w-3 h-3 text-secondary fill-secondary" />
                    <span className="text-xs text-foreground font-medium">{p.farmerRating || 4.0}</span>
                    <span className="text-xs text-foreground font-medium ml-0.5">{p.farmerName}</span>
                    {p.farmerVerified && (
                      <CheckCircle2 className="w-3 h-3 text-primary" />
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{p.farmerLocation}</span>
                  </div>
                  <div className="hidden md:flex items-center gap-1">
                    <Phone className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{p.farmerContact}</span>
                  </div>
                  <Button
                    size="sm"
                    disabled={isOutOfStock}
                    className="w-full mt-2 bg-secondary text-secondary-foreground hover:bg-secondary/90 h-9 md:h-10 disabled:opacity-50"
                    onClick={() => { addToCart(p); toast.success(`${p.name} added to cart`); }}
                  >
                    {isOutOfStock ? t('outOfStock') : t('addToCart')}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <p>{t('noProducts')}</p>
          </div>
        )}
      </div>

      <BottomNav role="consumer" />
    </div>
  );
};

export default ConsumerBrowse;
