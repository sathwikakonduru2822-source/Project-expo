import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import BottomNav from '@/components/BottomNav';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Bell, CheckCircle2, XCircle } from 'lucide-react';
import { toast } from 'sonner';

const FarmerOrders = () => {
  const { t } = useLanguage();
  const { orders, updateOrderStatus, notifications, markNotificationRead, unreadCount } = useApp();
  const myOrders = orders.filter(o => o.items.some(i => i.product.farmerId === 'f1'));

  const handleAccept = (orderId: string) => {
    updateOrderStatus(orderId, 'confirmed', true);
    toast.success('Order accepted ✅');
  };

  const handleReject = (orderId: string) => {
    updateOrderStatus(orderId, 'placed', false);
    toast.error('Order rejected');
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-primary text-primary-foreground p-6 rounded-b-3xl">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold flex items-center gap-2"><ShoppingCart className="w-6 h-6" /> {t('orders')}</h1>
          <div className="relative">
            <Bell className="w-6 h-6" />
            {unreadCount > 0 && (
              <span className="absolute -top-2 -right-2 w-5 h-5 bg-secondary text-secondary-foreground text-xs font-bold rounded-full flex items-center justify-center animate-pulse">
                {unreadCount}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Notifications */}
      {notifications.length > 0 && (
        <div className="px-4 mt-4">
          <h2 className="text-sm font-bold text-foreground mb-2 flex items-center gap-1">
            <Bell className="w-4 h-4 text-secondary" /> {t('notifications')}
          </h2>
          <div className="space-y-2">
            {notifications.slice(0, 5).map(n => (
              <div
                key={n.id}
                onClick={() => markNotificationRead(n.id)}
                className={`p-3 rounded-lg border text-sm cursor-pointer transition-all ${
                  n.read ? 'bg-card text-muted-foreground' : 'bg-secondary/10 border-secondary/30 text-foreground font-medium'
                }`}
              >
                <p>{n.message}</p>
                <p className="text-[10px] text-muted-foreground mt-1">{n.timestamp}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="px-4 mt-4 space-y-3">
        {myOrders.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>{t('noProducts')}</p>
          </div>
        ) : myOrders.map(o => (
          <div key={o.id} className="bg-card rounded-xl border p-4 animate-fade-in">
            <div className="flex justify-between items-center mb-2">
              <p className="font-semibold text-foreground">#{o.id.slice(-6)}</p>
              <span className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary font-medium">{o.status}</span>
            </div>
            {o.items.filter(i => i.product.farmerId === 'f1').map(i => (
              <p key={i.product.id} className="text-sm text-muted-foreground">{i.product.image} {i.product.name} × {i.qty}</p>
            ))}
            <p className="text-sm text-muted-foreground mt-1">👤 {o.buyerName || 'Customer'}</p>
            <p className="text-xs text-muted-foreground">{o.date} · ₹{o.total}</p>

            {/* Accept / Reject buttons for new orders */}
            {o.status === 'placed' && !o.farmerAccepted && (
              <div className="flex gap-2 mt-3">
                <Button size="sm" className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => handleAccept(o.id)}>
                  <CheckCircle2 className="w-4 h-4 mr-1" /> {t('accept')}
                </Button>
                <Button size="sm" variant="outline" className="flex-1 text-destructive border-destructive hover:bg-destructive/10" onClick={() => handleReject(o.id)}>
                  <XCircle className="w-4 h-4 mr-1" /> {t('reject')}
                </Button>
              </div>
            )}
            {o.farmerAccepted && (
              <p className="text-xs text-primary font-medium mt-2 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> {t('farmerAccepted')}
              </p>
            )}
          </div>
        ))}
      </div>
      <BottomNav role="farmer" />
    </div>
  );
};

export default FarmerOrders;
