import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import BottomNav from '@/components/BottomNav';
import { Package, CheckCircle2, Truck, ShoppingBag, Clock } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

const statusSteps = ['placed', 'confirmed', 'shipped', 'delivered'] as const;

const ConsumerOrders = () => {
  const { t } = useLanguage();
  const { orders } = useApp();

  const statusLabels: Record<string, string> = {
    placed: t('orderPlaced'),
    confirmed: t('farmerAccepted'),
    shipped: t('outForDelivery'),
    delivered: t('delivered'),
  };

  const statusIcons: Record<string, typeof Package> = {
    placed: ShoppingBag,
    confirmed: CheckCircle2,
    shipped: Truck,
    delivered: CheckCircle2,
  };

  const getProgress = (status: string) => {
    const idx = statusSteps.indexOf(status as any);
    return ((idx + 1) / statusSteps.length) * 100;
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-secondary text-secondary-foreground p-6 rounded-b-3xl">
        <h1 className="text-2xl font-bold flex items-center gap-2"><Package className="w-6 h-6" /> {t('orders')}</h1>
      </div>
      <div className="px-4 mt-4 space-y-3">
        {orders.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Package className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>{t('noProducts')}</p>
          </div>
        ) : orders.map(o => (
          <div key={o.id} className="bg-card rounded-xl border p-4 animate-fade-in">
            <div className="flex justify-between items-center mb-2">
              <p className="font-semibold text-foreground">#{o.id.slice(-6)}</p>
              <span className="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary font-medium">{statusLabels[o.status]}</span>
            </div>
            {o.items.map(i => (
              <p key={i.product.id} className="text-sm text-muted-foreground">{i.product.image} {i.product.name} × {i.qty}</p>
            ))}

            {/* Delivery slot */}
            {o.deliverySlot && (
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                <Clock className="w-3 h-3" /> {t(o.deliverySlot)}
              </p>
            )}

            {/* Order Timeline */}
            <div className="mt-3">
              <Progress value={getProgress(o.status)} className="h-2 mb-2" />
              <div className="flex justify-between">
                {statusSteps.map((step, idx) => {
                  const Icon = statusIcons[step];
                  const currentIdx = statusSteps.indexOf(o.status);
                  const isActive = idx <= currentIdx;
                  return (
                    <div key={step} className="flex flex-col items-center flex-1">
                      <Icon className={`w-4 h-4 ${isActive ? 'text-primary' : 'text-muted-foreground/30'}`} />
                      <span className={`text-[9px] mt-0.5 text-center leading-tight ${isActive ? 'text-primary font-medium' : 'text-muted-foreground/40'}`}>
                        {statusLabels[step]}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-between items-center mt-2 pt-2 border-t">
              <p className="text-xs text-muted-foreground">{o.paymentMethod === 'cod' ? t('cod') : t('online')} · {o.date}</p>
              <p className="font-bold text-primary">₹{o.total}</p>
            </div>
          </div>
        ))}
      </div>
      <BottomNav role="consumer" />
    </div>
  );
};

export default ConsumerOrders;
