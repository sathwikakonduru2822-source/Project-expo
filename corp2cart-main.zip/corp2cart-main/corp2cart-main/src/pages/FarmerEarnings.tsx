import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import BottomNav from '@/components/BottomNav';
import { TrendingUp } from 'lucide-react';

const FarmerEarnings = () => {
  const { t } = useLanguage();
  const { orders } = useApp();
  const myOrders = orders.filter(o => o.items.some(i => i.product.farmerId === 'f1'));
  const totalEarnings = myOrders.reduce((s, o) => s + o.total, 0);

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-primary text-primary-foreground p-6 rounded-b-3xl">
        <h1 className="text-2xl font-bold flex items-center gap-2"><TrendingUp className="w-6 h-6" /> {t('earnings')}</h1>
      </div>
      <div className="px-4 mt-4">
        <div className="bg-card rounded-xl border p-6 text-center animate-fade-in">
          <p className="text-muted-foreground text-sm">{t('total')} {t('earnings')}</p>
          <p className="text-4xl font-bold text-primary mt-2">₹{totalEarnings}</p>
          <p className="text-muted-foreground text-sm mt-2">{myOrders.length} {t('orders')}</p>
        </div>

        <div className="mt-6 space-y-3">
          {myOrders.map(o => (
            <div key={o.id} className="bg-card rounded-xl border p-4 flex justify-between items-center">
              <div>
                <p className="font-medium text-foreground">#{o.id.slice(-6)}</p>
                <p className="text-xs text-muted-foreground">{o.date}</p>
              </div>
              <p className="font-bold text-primary">+₹{o.total}</p>
            </div>
          ))}
        </div>
      </div>
      <BottomNav role="farmer" />
    </div>
  );
};

export default FarmerEarnings;
