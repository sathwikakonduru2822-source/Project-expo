import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import BottomNav from '@/components/BottomNav';
import { Users, Package, BarChart3, TrendingUp, CheckCircle, Clock, XCircle } from 'lucide-react';

const AdminDashboard = () => {
  const { t } = useLanguage();
  const { products, orders } = useApp();

  const stats = [
    { label: t('totalFarmers'), value: 3, icon: Users, color: 'bg-primary/10 text-primary' },
    { label: t('totalConsumers'), value: 12, icon: Users, color: 'bg-secondary/10 text-secondary' },
    { label: t('totalProducts'), value: products.length, icon: Package, color: 'bg-primary/10 text-primary' },
    { label: t('revenue'), value: `₹${orders.reduce((s, o) => s + o.total, 0)}`, icon: TrendingUp, color: 'bg-secondary/10 text-secondary' },
  ];

  const pendingProducts = products.filter(p => p.status === 'pending');

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-foreground text-background p-6 rounded-b-3xl">
        <p className="text-sm opacity-70">🛠️ {t('admin')}</p>
        <h1 className="text-2xl font-bold">{t('dashboard')}</h1>
      </div>

      <div className="grid grid-cols-2 gap-3 px-4 -mt-4">
        {stats.map((s, i) => (
          <div key={i} className="bg-card rounded-xl border p-4 animate-fade-in" style={{ animationDelay: `${i * 0.1}s` }}>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-2 ${s.color}`}>
              <s.icon className="w-4 h-4" />
            </div>
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Pending approvals */}
      <div className="px-4 mt-6">
        <h2 className="text-lg font-bold text-foreground mb-3">{t('approveListings')} ({pendingProducts.length})</h2>
        <div className="space-y-3">
          {pendingProducts.map(p => (
            <div key={p.id} className="bg-card rounded-xl border p-4 animate-fade-in">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{p.image}</span>
                <div className="flex-1">
                  <p className="font-semibold text-foreground">{p.name}</p>
                  <p className="text-sm text-muted-foreground">by {p.farmerName} · {p.farmerLocation}</p>
                  <p className="text-sm text-primary font-medium">₹{p.price}/{p.unit}</p>
                </div>
              </div>
              <div className="flex gap-2 mt-3">
                <button className="flex-1 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium flex items-center justify-center gap-1">
                  <CheckCircle className="w-4 h-4" /> {t('approved')}
                </button>
                <button className="flex-1 py-2 rounded-lg bg-destructive text-destructive-foreground text-sm font-medium flex items-center justify-center gap-1">
                  <XCircle className="w-4 h-4" /> {t('rejected')}
                </button>
              </div>
            </div>
          ))}
          {pendingProducts.length === 0 && (
            <p className="text-center text-muted-foreground py-8">{t('noProducts')}</p>
          )}
        </div>
      </div>

      {/* Recent orders */}
      <div className="px-4 mt-6">
        <h2 className="text-lg font-bold text-foreground mb-3">{t('transactions')}</h2>
        <div className="space-y-3">
          {orders.slice(0, 5).map(o => (
            <div key={o.id} className="bg-card rounded-xl border p-4 flex justify-between items-center">
              <div>
                <p className="font-medium text-foreground">#{o.id.slice(-6)}</p>
                <p className="text-xs text-muted-foreground">{o.date} · {o.items.length} items</p>
              </div>
              <p className="font-bold text-primary">₹{o.total}</p>
            </div>
          ))}
        </div>
      </div>

      <BottomNav role="admin" />
    </div>
  );
};

export default AdminDashboard;
