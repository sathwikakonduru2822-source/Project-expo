import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import BottomNav from '@/components/BottomNav';
import { BarChart3 } from 'lucide-react';

const AdminAnalytics = () => {
  const { t } = useLanguage();
  const { products, orders } = useApp();

  const categoryStats = ['vegetables', 'fruits', 'grains', 'dairy', 'poultry'].map(cat => ({
    name: t(cat),
    count: products.filter(p => p.category === cat).length,
  }));

  const maxCount = Math.max(...categoryStats.map(c => c.count), 1);

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-foreground text-background p-6 rounded-b-3xl">
        <h1 className="text-2xl font-bold flex items-center gap-2"><BarChart3 className="w-6 h-6" /> {t('analytics')}</h1>
      </div>

      <div className="px-4 mt-4 space-y-4">
        <div className="bg-card rounded-xl border p-4">
          <p className="font-semibold text-foreground mb-4">{t('totalProducts')} by {t('category')}</p>
          <div className="space-y-3">
            {categoryStats.map(c => (
              <div key={c.name}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-foreground">{c.name}</span>
                  <span className="text-muted-foreground">{c.count}</span>
                </div>
                <div className="h-3 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(c.count / maxCount) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card rounded-xl border p-4 text-center">
          <p className="text-muted-foreground text-sm">{t('totalOrders')}</p>
          <p className="text-4xl font-bold text-primary mt-1">{orders.length}</p>
        </div>

        <div className="bg-card rounded-xl border p-4 text-center">
          <p className="text-muted-foreground text-sm">{t('revenue')}</p>
          <p className="text-4xl font-bold text-secondary mt-1">₹{orders.reduce((s, o) => s + o.total, 0)}</p>
        </div>
      </div>

      <BottomNav role="admin" />
    </div>
  );
};

export default AdminAnalytics;
