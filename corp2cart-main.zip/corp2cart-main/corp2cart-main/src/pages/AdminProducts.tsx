import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import BottomNav from '@/components/BottomNav';
import { Package, CheckCircle, XCircle } from 'lucide-react';

const AdminProducts = () => {
  const { t } = useLanguage();
  const { products, setProducts } = useApp();

  const handleApprove = (id: string) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, status: 'approved' } : p));
  };

  const handleReject = (id: string) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, status: 'rejected' } : p));
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-foreground text-background p-6 rounded-b-3xl">
        <h1 className="text-2xl font-bold flex items-center gap-2"><Package className="w-6 h-6" /> {t('approveListings')}</h1>
      </div>
      <div className="px-4 mt-4 space-y-3">
        {products.map(p => (
          <div key={p.id} className="bg-card rounded-xl border p-4 animate-fade-in">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{p.image}</span>
              <div className="flex-1">
                <p className="font-semibold text-foreground">{p.name}</p>
                <p className="text-xs text-muted-foreground">{p.farmerName} · {p.farmerLocation}</p>
                <p className="text-sm text-primary font-medium">₹{p.price}/{p.unit}</p>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                p.status === 'approved' ? 'bg-primary/10 text-primary' : p.status === 'rejected' ? 'bg-destructive/10 text-destructive' : 'bg-secondary/10 text-secondary'
              }`}>{t(p.status)}</span>
            </div>
            {p.status === 'pending' && (
              <div className="flex gap-2 mt-3">
                <button onClick={() => handleApprove(p.id)} className="flex-1 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium flex items-center justify-center gap-1">
                  <CheckCircle className="w-4 h-4" /> {t('approved')}
                </button>
                <button onClick={() => handleReject(p.id)} className="flex-1 py-2 rounded-lg bg-destructive text-destructive-foreground text-sm font-medium flex items-center justify-center gap-1">
                  <XCircle className="w-4 h-4" /> {t('rejected')}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
      <BottomNav role="admin" />
    </div>
  );
};

export default AdminProducts;
