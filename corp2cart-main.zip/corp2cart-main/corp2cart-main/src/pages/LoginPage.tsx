import { useState } from 'react';
import { useLanguage, languageNames, Language } from '@/contexts/LanguageContext';
import { useApp, UserRole } from '@/contexts/AppContext';
import { useNavigate } from 'react-router-dom';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Sprout, ShoppingCart, Globe, User } from 'lucide-react';

const LoginPage = () => {
  const { t, language, setLanguage } = useLanguage();
  const { setRole, setIsLoggedIn, setUserName } = useApp();
  const navigate = useNavigate();

  const [isRegister, setIsRegister] = useState(false);
  const [selectedRole, setSelectedRole] = useState<UserRole>('consumer');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [village, setVillage] = useState('');
  const [contact, setContact] = useState('');
  const [farmType, setFarmType] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRole(selectedRole);
    setIsLoggedIn(true);
    setUserName(name || 'User');
    if (selectedRole === 'farmer') navigate('/farmer');
    else if (selectedRole === 'admin') navigate('/admin');
    else navigate('/consumer');
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Language selector */}
      <div className="flex justify-end p-4">
        <Select value={language} onValueChange={(v) => setLanguage(v as Language)}>
          <SelectTrigger className="w-40 bg-card">
            <Globe className="w-4 h-4 mr-2 text-primary" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {(Object.entries(languageNames) as [Language, string][]).map(([code, label]) => (
              <SelectItem key={code} value={code}>{label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Main content */}
      <div className="flex-1 flex items-center justify-center px-4 pb-8">
        <div className="w-full max-w-md animate-fade-in">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary mb-4">
              <Sprout className="w-10 h-10 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">{t('appName')}</h1>
            <p className="text-muted-foreground mt-1 text-lg">{t('tagline')}</p>
          </div>

          {/* Form card */}
          <div className="bg-card rounded-lg border p-6 shadow-sm">
            <div className="flex mb-6 rounded-lg overflow-hidden border">
              <button
                onClick={() => setIsRegister(false)}
                className={`flex-1 py-3 text-center font-semibold transition-colors ${!isRegister ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground'}`}
              >
                {t('login')}
              </button>
              <button
                onClick={() => setIsRegister(true)}
                className={`flex-1 py-3 text-center font-semibold transition-colors ${isRegister ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground'}`}
              >
                {t('register')}
              </button>
            </div>

            {/* Role selection */}
            <div className="mb-5">
              <label className="block text-sm font-medium text-foreground mb-2">{t('selectRole')}</label>
              <div className="grid grid-cols-3 gap-2">
                {(['farmer', 'consumer', 'admin'] as UserRole[]).map(r => (
                  <button
                    key={r}
                    onClick={() => setSelectedRole(r)}
                    className={`py-3 px-2 rounded-lg border-2 text-center font-semibold text-sm transition-all ${
                      selectedRole === r
                        ? r === 'farmer' ? 'border-primary bg-farmer-light text-primary'
                          : r === 'consumer' ? 'border-secondary bg-consumer-light text-secondary'
                          : 'border-foreground bg-muted text-foreground'
                        : 'border-border text-muted-foreground hover:border-primary/40'
                    }`}
                  >
                    {r === 'farmer' ? '🧑‍🌾' : r === 'consumer' ? '🛒' : '🛠️'}
                    <span className="block mt-1">{t(r)}</span>
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {isRegister && (
                <>
                  <Input
                    placeholder={t('name')}
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="h-12 text-base"
                    required
                  />
                  {selectedRole === 'farmer' && (
                    <>
                      <Input
                        placeholder={t('village')}
                        value={village}
                        onChange={e => setVillage(e.target.value)}
                        className="h-12 text-base"
                      />
                      <Input
                        placeholder={t('contact')}
                        value={contact}
                        onChange={e => setContact(e.target.value)}
                        className="h-12 text-base"
                        type="tel"
                      />
                      <Select value={farmType} onValueChange={setFarmType}>
                        <SelectTrigger className="h-12 text-base">
                          <SelectValue placeholder={t('farmType')} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="vegetables">{t('vegetables')}</SelectItem>
                          <SelectItem value="fruits">{t('fruits')}</SelectItem>
                          <SelectItem value="dairy">{t('dairy')}</SelectItem>
                          <SelectItem value="poultry">{t('poultry')}</SelectItem>
                          <SelectItem value="grains">{t('grains')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </>
                  )}
                </>
              )}

              <Input
                placeholder={t('email')}
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="h-12 text-base"
                type="email"
                required
              />
              <Input
                placeholder={t('password')}
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="h-12 text-base"
                type="password"
                required
              />

              <Button type="submit" className="w-full h-12 text-lg font-semibold bg-primary hover:bg-primary/90">
                {isRegister ? t('register') : t('login')}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
