import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import BottomNav from '@/components/BottomNav';
import { Package } from 'lucide-react';

const FarmerProducts = () => {
  const { t } = useLanguage();
  const { products } = useApp();
  const myProducts = products.filter(p => p.farmerId === 'f1');

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-primary text-primary-foreground p-6 rounded-b-3xl">
        <h1 className="text-2xl font-bold flex items-center gap-2"><Package className="w-6 h-6" /> {t('myProducts')}</h1>
      </div>
      <div className="px-4 mt-4 space-y-3">
        {myProducts.map(p => (
          <div key={p.id} className="bg-card rounded-xl border p-4 flex items-center gap-4 animate-fade-in">
            <span className="text-4xl">{p.image}</span>
            <div className="flex-1">
              <p className="font-semibold text-lg text-foreground">{p.name}</p>
              <p className="text-muted-foreground">₹{p.price}/{p.unit}</p>
              <p className="text-sm text-muted-foreground">{p.quantity} {t('available')}</p>
            </div>
            <span className={`text-xs px-2 py-1 rounded-full font-medium ${
              p.status === 'approved' ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'
            }`}>{t(p.status)}</span>
          </div>
        ))}
      </div>
      <BottomNav role="farmer" />
    </div>
  );
};

export default FarmerProducts;
