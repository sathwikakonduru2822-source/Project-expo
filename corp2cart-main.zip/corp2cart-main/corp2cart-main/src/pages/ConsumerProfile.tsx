import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import BottomNav from '@/components/BottomNav';
import { User } from 'lucide-react';

const ConsumerProfile = () => {
  const { t } = useLanguage();
  const { userName, orders } = useApp();

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-secondary text-secondary-foreground p-6 rounded-b-3xl text-center">
        <div className="w-20 h-20 rounded-full bg-secondary-foreground/20 flex items-center justify-center mx-auto mb-3">
          <User className="w-10 h-10" />
        </div>
        <h1 className="text-2xl font-bold">{userName || 'Consumer'}</h1>
      </div>
      <div className="px-4 mt-4 space-y-3">
        <div className="bg-card rounded-xl border p-4 text-center">
          <p className="text-muted-foreground text-sm">{t('totalOrders')}</p>
          <p className="text-3xl font-bold text-primary">{orders.length}</p>
        </div>
      </div>
      <BottomNav role="consumer" />
    </div>
  );
};

export default ConsumerProfile;
