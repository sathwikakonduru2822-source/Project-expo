import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApp, Product } from '@/contexts/AppContext';
import BottomNav from '@/components/BottomNav';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Package, TrendingUp, ShoppingCart, Bell, Lightbulb } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

// Simulated demand-based price recommendations
const priceRecommendations: Record<string, number> = {
  'Tomatoes': 35,
  'Mangoes': 110,
  'Bananas': 45,
  'Wheat': 48,
  'Potatoes': 28,
};

const FarmerDashboard = () => {
  const { t } = useLanguage();
  const { products, setProducts, orders, userName, unreadCount } = useApp();

  const myProducts = products.filter(p => p.farmerId === 'f1');
  const myOrders = orders.filter(o => o.items.some(i => i.product.farmerId === 'f1'));

  const todayEarnings = myOrders.reduce((sum, o) => sum + o.total, 0);

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-primary text-primary-foreground p-6 rounded-b-3xl">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm opacity-80">{t('welcome')}</p>
            <h1 className="text-2xl font-bold">🧑‍🌾 {userName || 'Farmer'}</h1>
          </div>
          <div className="relative">
            <Bell className="w-6 h-6" />
            {unreadCount > 0 && (
              <span className="absolute -top-2 -right-2 w-5 h-5 bg-secondary text-secondary-foreground text-xs font-bold rounded-full flex items-center justify-center animate-pulse">
                {unreadCount}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 px-4 -mt-4">
        {[
          { label: t('todayEarnings'), value: `₹${todayEarnings}`, icon: TrendingUp, color: 'bg-primary/10 text-primary' },
          { label: t('totalOrders'), value: myOrders.length, icon: ShoppingCart, color: 'bg-secondary/10 text-secondary' },
          { label: t('activeProducts'), value: myProducts.filter(p => p.status === 'approved').length, icon: Package, color: 'bg-primary/10 text-primary' },
          { label: t('pendingOrders'), value: myOrders.filter(o => o.status === 'placed').length, icon: ShoppingCart, color: 'bg-secondary/10 text-secondary' },
        ].map((s, i) => (
          <div key={i} className="bg-card rounded-xl border p-4 animate-fade-in" style={{ animationDelay: `${i * 0.1}s` }}>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-2 ${s.color}`}>
              <s.icon className="w-4 h-4" />
            </div>
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Smart Price Recommendations */}
      <div className="px-4 mt-6">
        <h2 className="text-lg font-bold text-foreground mb-3 flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-secondary" /> {t('smartPrice')}
        </h2>
        <div className="space-y-2">
          {myProducts.filter(p => priceRecommendations[p.name]).map(p => {
            const rec = priceRecommendations[p.name];
            const diff = rec - p.price;
            return (
              <div key={p.id} className="bg-secondary/5 border border-secondary/20 rounded-lg p-3 flex items-center gap-3">
                <span className="text-2xl">{p.image}</span>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-foreground">{p.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {t('recommendedPrice').replace('{price}', String(rec)).replace('{unit}', p.unit)}
                  </p>
                </div>
                <span className={`text-xs font-bold px-2 py-1 rounded-full ${diff > 0 ? 'bg-primary/10 text-primary' : 'bg-destructive/10 text-destructive'}`}>
                  {diff > 0 ? '↑' : '↓'} ₹{Math.abs(diff)}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Products */}
      <div className="px-4 mt-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold text-foreground">{t('myProducts')}</h2>
          <AddProductDialog />
        </div>
        <div className="space-y-3">
          {myProducts.map(p => (
            <div key={p.id} className="bg-card rounded-xl border p-4 flex items-center gap-4">
              <span className="text-3xl">{p.image}</span>
              <div className="flex-1">
                <p className="font-semibold text-foreground">{p.name}</p>
                <p className="text-sm text-muted-foreground">₹{p.price}/{p.unit} · {p.quantity} {t('available')}</p>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                p.status === 'approved' ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'
              }`}>
                {t(p.status)}
              </span>
            </div>
          ))}
        </div>
      </div>

      <BottomNav role="farmer" />
    </div>
  );
};

const AddProductDialog = () => {
  const { t } = useLanguage();
  const { setProducts } = useApp();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [price, setPrice] = useState('');
  const [unit, setUnit] = useState('kg');
  const [quantity, setQuantity] = useState('');

  const emojis: Record<string, string> = { vegetables: '🥬', fruits: '🍎', grains: '🌾', dairy: '🥛', poultry: '🥚' };

  const handleAdd = () => {
    if (!name || !category || !price || !quantity) return;
    const newProduct: Product = {
      id: Date.now().toString(),
      name,
      category,
      image: emojis[category] || '📦',
      price: Number(price),
      unit,
      quantity: Number(quantity),
      farmerId: 'f1',
      farmerName: 'Raju',
      farmerLocation: 'Anantapur',
      farmerContact: '9876543210',
      status: 'pending',
      farmerVerified: true,
      farmerRating: 4.5,
    };
    setProducts(prev => [...prev, newProduct]);
    setOpen(false);
    setName(''); setCategory(''); setPrice(''); setQuantity('');
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="bg-secondary text-secondary-foreground hover:bg-secondary/90">
          <Plus className="w-4 h-4 mr-1" /> {t('addProduct')}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>{t('addProduct')}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 mt-2">
          <Input placeholder={t('productName')} value={name} onChange={e => setName(e.target.value)} className="h-12" />
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="h-12"><SelectValue placeholder={t('category')} /></SelectTrigger>
            <SelectContent>
              {['vegetables', 'fruits', 'grains', 'dairy', 'poultry'].map(c => (
                <SelectItem key={c} value={c}>{t(c)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex gap-2">
            <Input placeholder={t('price')} value={price} onChange={e => setPrice(e.target.value)} type="number" className="h-12 flex-1" />
            <Select value={unit} onValueChange={setUnit}>
              <SelectTrigger className="h-12 w-28"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="kg">{t('perKg')}</SelectItem>
                <SelectItem value="litre">{t('perLitre')}</SelectItem>
                <SelectItem value="piece">{t('perPiece')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Input placeholder={t('quantity')} value={quantity} onChange={e => setQuantity(e.target.value)} type="number" className="h-12" />
          <Button onClick={handleAdd} className="w-full h-12 bg-primary">{t('addProduct')}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default FarmerDashboard;
