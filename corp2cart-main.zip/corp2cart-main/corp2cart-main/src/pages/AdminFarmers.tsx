import { useLanguage } from '@/contexts/LanguageContext';
import BottomNav from '@/components/BottomNav';
import { Users } from 'lucide-react';

const farmers = [
  { name: 'Raju', location: 'Anantapur', contact: '9876543210', type: 'Vegetables' },
  { name: 'Lakshmi', location: 'Warangal', contact: '9876543211', type: 'Dairy' },
  { name: 'Suresh', location: 'Guntur', contact: '9876543212', type: 'Poultry' },
];

const AdminFarmers = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-foreground text-background p-6 rounded-b-3xl">
        <h1 className="text-2xl font-bold flex items-center gap-2"><Users className="w-6 h-6" /> {t('manageFarmers')}</h1>
      </div>
      <div className="px-4 mt-4 space-y-3">
        {farmers.map((f, i) => (
          <div key={i} className="bg-card rounded-xl border p-4 animate-fade-in">
            <p className="font-semibold text-foreground text-lg">🧑‍🌾 {f.name}</p>
            <p className="text-sm text-muted-foreground">📍 {f.location}</p>
            <p className="text-sm text-muted-foreground">📞 {f.contact}</p>
            <p className="text-sm text-primary font-medium mt-1">{f.type}</p>
          </div>
        ))}
      </div>
      <BottomNav role="admin" />
    </div>
  );
};

export default AdminFarmers;
