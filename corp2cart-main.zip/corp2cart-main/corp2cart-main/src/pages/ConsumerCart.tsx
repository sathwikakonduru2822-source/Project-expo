import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useApp, Order, DeliverySlot } from '@/contexts/AppContext';
import { useNavigate } from 'react-router-dom';
import BottomNav from '@/components/BottomNav';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Plus, Trash2, CreditCard, Banknote, Clock, Sun, Sunset } from 'lucide-react';
import { toast } from 'sonner';

const ConsumerCart = () => {
  const { t } = useLanguage();
  const { cart, removeFromCart, addToCart, clearCart, addOrder, userName } = useApp();
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState<'online' | 'cod'>('cod');
  const [deliverySlot, setDeliverySlot] = useState<DeliverySlot>('morning');

  const total = cart.reduce((s, c) => s + c.product.price * c.qty, 0);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    const order: Order = {
      id: Date.now().toString(),
      items: [...cart],
      total,
      status: 'placed',
      paymentMethod,
      date: new Date().toLocaleDateString(),
      buyerName: userName || 'Customer',
      deliverySlot,
    };
    addOrder(order);
    clearCart();
    toast.success(t('placeOrder') + ' ✅');
    navigate('/consumer/orders');
  };

  const slots: { key: DeliverySlot; icon: typeof Clock; }[] = [
    { key: 'morning', icon: Sun },
    { key: 'afternoon', icon: Clock },
    { key: 'evening', icon: Sunset },
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="bg-secondary text-secondary-foreground p-6 rounded-b-3xl">
        <h1 className="text-2xl font-bold flex items-center gap-2"><ShoppingCart className="w-6 h-6" /> {t('cart')}</h1>
      </div>

      <div className="px-4 mt-4 space-y-3">
        {cart.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>{t('noProducts')}</p>
          </div>
        ) : (
          <>
            {cart.map(c => (
              <div key={c.product.id} className="bg-card rounded-xl border p-4 flex items-center gap-3 animate-fade-in">
                <span className="text-3xl">{c.product.image}</span>
                <div className="flex-1">
                  <p className="font-semibold text-foreground">{c.product.name}</p>
                  <p className="text-sm text-muted-foreground">₹{c.product.price}/{c.product.unit}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-foreground w-6 text-center">{c.qty}</span>
                  <Button size="icon" variant="outline" className="w-8 h-8" onClick={() => addToCart(c.product)}>
                    <Plus className="w-3 h-3" />
                  </Button>
                  <Button size="icon" variant="outline" className="w-8 h-8 text-destructive" onClick={() => removeFromCart(c.product.id)}>
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))}

            {/* Delivery Slot */}
            <div className="bg-card rounded-xl border p-4">
              <p className="font-semibold text-foreground mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" /> {t('deliverySlot')}
              </p>
              <div className="grid grid-cols-3 gap-2">
                {slots.map(s => (
                  <button
                    key={s.key}
                    onClick={() => setDeliverySlot(s.key)}
                    className={`p-2.5 rounded-lg border-2 flex flex-col items-center gap-1 text-xs font-medium transition-all ${
                      deliverySlot === s.key ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground'
                    }`}
                  >
                    <s.icon className="w-4 h-4" />
                    {t(s.key)}
                  </button>
                ))}
              </div>
            </div>

            {/* Payment */}
            <div className="bg-card rounded-xl border p-4">
              <p className="font-semibold text-foreground mb-3">{t('payment')}</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setPaymentMethod('online')}
                  className={`p-3 rounded-lg border-2 flex items-center gap-2 text-sm font-medium transition-all ${
                    paymentMethod === 'online' ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground'
                  }`}
                >
                  <CreditCard className="w-4 h-4" /> {t('online')}
                </button>
                <button
                  onClick={() => setPaymentMethod('cod')}
                  className={`p-3 rounded-lg border-2 flex items-center gap-2 text-sm font-medium transition-all ${
                    paymentMethod === 'cod' ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground'
                  }`}
                >
                  <Banknote className="w-4 h-4" /> {t('cod')}
                </button>
              </div>
            </div>

            {/* Total & Checkout */}
            <div className="bg-card rounded-xl border p-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{t('total')}</p>
                <p className="text-2xl font-bold text-primary">₹{total}</p>
              </div>
              <Button onClick={handleCheckout} className="h-12 px-8 bg-secondary text-secondary-foreground hover:bg-secondary/90 text-lg font-semibold">
                {t('placeOrder')}
              </Button>
            </div>
          </>
        )}
      </div>

      <BottomNav role="consumer" />
    </div>
  );
};

export default ConsumerCart;
