import { useLanguage } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Package, ShoppingCart, User, BarChart3, LogOut } from 'lucide-react';

interface BottomNavProps {
  role: 'farmer' | 'consumer' | 'admin';
}

const BottomNav = ({ role }: BottomNavProps) => {
  const { t } = useLanguage();
  const { setIsLoggedIn, setRole } = useApp();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    setIsLoggedIn(false);
    setRole(null);
    navigate('/');
  };

  const farmerTabs = [
    { path: '/farmer', icon: Home, label: t('dashboard') },
    { path: '/farmer/products', icon: Package, label: t('myProducts') },
    { path: '/farmer/orders', icon: ShoppingCart, label: t('orders') },
    { path: '/farmer/earnings', icon: BarChart3, label: t('earnings') },
  ];

  const consumerTabs = [
    { path: '/consumer', icon: Home, label: t('browse') },
    { path: '/consumer/cart', icon: ShoppingCart, label: t('cart') },
    { path: '/consumer/orders', icon: Package, label: t('orders') },
    { path: '/consumer/profile', icon: User, label: t('profile') },
  ];

  const adminTabs = [
    { path: '/admin', icon: Home, label: t('dashboard') },
    { path: '/admin/farmers', icon: User, label: t('farmer') },
    { path: '/admin/products', icon: Package, label: t('approveListings') },
    { path: '/admin/analytics', icon: BarChart3, label: t('analytics') },
  ];

  const tabs = role === 'farmer' ? farmerTabs : role === 'admin' ? adminTabs : consumerTabs;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t z-50 md:hidden">
      <div className="max-w-lg mx-auto flex justify-around items-center h-16">
        {tabs.map(tab => {
          const active = location.pathname === tab.path;
          return (
            <button
              key={tab.path}
              onClick={() => navigate(tab.path)}
              className={`flex flex-col items-center justify-center flex-1 py-2 transition-colors ${
                active ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              <span className="text-[10px] mt-1 font-medium">{tab.label}</span>
            </button>
          );
        })}
        <button
          onClick={handleLogout}
          className="flex flex-col items-center justify-center flex-1 py-2 text-muted-foreground hover:text-destructive transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-[10px] mt-1 font-medium">{t('logout')}</span>
        </button>
      </div>
    </nav>
  );
};

export default BottomNav;
