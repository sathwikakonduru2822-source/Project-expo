import { useLanguage, languageNames, Language } from '@/contexts/LanguageContext';
import { useApp } from '@/contexts/AppContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { Search, ShoppingCart, Heart, Sprout, LogOut, Globe } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import ThemeToggle from './ThemeToggle';

interface TopNavProps {
  role: 'farmer' | 'consumer' | 'admin';
  search?: string;
  onSearchChange?: (v: string) => void;
}

const TopNav = ({ role, search, onSearchChange }: TopNavProps) => {
  const { t, language, setLanguage } = useLanguage();
  const { cart, setIsLoggedIn, setRole, wishlist } = useApp();
  const navigate = useNavigate();
  const location = useLocation();

  const cartCount = cart.reduce((s, c) => s + c.qty, 0);

  const handleLogout = () => {
    setIsLoggedIn(false);
    setRole(null);
    navigate('/');
  };

  const consumerLinks = [
    { path: '/consumer', label: t('browse') },
    { path: '/consumer/orders', label: t('orders') },
    { path: '/consumer/profile', label: t('profile') },
  ];

  const farmerLinks = [
    { path: '/farmer', label: t('dashboard') },
    { path: '/farmer/products', label: t('myProducts') },
    { path: '/farmer/orders', label: t('orders') },
    { path: '/farmer/earnings', label: t('earnings') },
  ];

  const adminLinks = [
    { path: '/admin', label: t('dashboard') },
    { path: '/admin/farmers', label: t('farmer') },
    { path: '/admin/products', label: t('approveListings') },
    { path: '/admin/analytics', label: t('analytics') },
  ];

  const links = role === 'farmer' ? farmerLinks : role === 'admin' ? adminLinks : consumerLinks;

  return (
    <header className="hidden md:block sticky top-0 z-50 bg-card/95 backdrop-blur-md border-b">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center h-16 gap-6">
          {/* Logo */}
          <button onClick={() => navigate(role === 'farmer' ? '/farmer' : role === 'admin' ? '/admin' : '/consumer')} className="flex items-center gap-2 shrink-0">
            <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center">
              <Sprout className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground" style={{ fontFamily: 'Poppins' }}>Crop2Cart</span>
          </button>

          {/* Nav Links */}
          <nav className="flex items-center gap-1">
            {links.map(link => (
              <button
                key={link.path}
                onClick={() => navigate(link.path)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  location.pathname === link.path
                    ? 'bg-primary/10 text-primary'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Search - consumer only */}
          {role === 'consumer' && onSearchChange && (
            <div className="flex-1 max-w-md relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder={t('search')}
                value={search || ''}
                onChange={e => onSearchChange(e.target.value)}
                className="pl-10 h-10 bg-muted/50 border-0"
              />
            </div>
          )}
          {role !== 'consumer' && <div className="flex-1" />}

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {/* Language */}
            <Select value={language} onValueChange={(v) => setLanguage(v as Language)}>
              <SelectTrigger className="w-28 h-9 text-xs border-0 bg-muted/50">
                <Globe className="w-3.5 h-3.5 mr-1" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.entries(languageNames) as [Language, string][]).map(([code, label]) => (
                  <SelectItem key={code} value={code}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <ThemeToggle />

            {/* Wishlist - consumer only */}
            {role === 'consumer' && (
              <Button variant="ghost" size="icon" className="relative rounded-full">
                <Heart className="w-5 h-5" />
                {wishlist.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-destructive text-destructive-foreground text-[10px] font-bold rounded-full flex items-center justify-center">
                    {wishlist.length}
                  </span>
                )}
              </Button>
            )}

            {/* Cart - consumer only */}
            {role === 'consumer' && (
              <Button variant="ghost" size="icon" className="relative rounded-full" onClick={() => navigate('/consumer/cart')}>
                <ShoppingCart className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-secondary text-secondary-foreground text-[10px] font-bold rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Button>
            )}

            <Button variant="ghost" size="sm" onClick={handleLogout} className="text-muted-foreground hover:text-destructive">
              <LogOut className="w-4 h-4 mr-1" />
              {t('logout')}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default TopNav;
