import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sprout, ShoppingCart } from 'lucide-react';

interface HeroSectionProps {
  onShopNow: () => void;
  onBecomeFarmer: () => void;
}

const HeroSection = ({ onShopNow, onBecomeFarmer }: HeroSectionProps) => {
  const { t } = useLanguage();

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-accent/30 to-secondary/10">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 text-[120px]">🌾</div>
        <div className="absolute bottom-10 right-10 text-[100px]">🍅</div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[80px]">🥬</div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-12 md:py-24 relative z-10">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-sm font-medium px-4 py-1.5 rounded-full mb-6">
            <Sprout className="w-4 h-4" />
            {t('appName')} — {t('directFromFarm')}
          </div>

          <h1 className="text-3xl md:text-5xl lg:text-6xl font-extrabold text-foreground leading-tight mb-4" style={{ fontFamily: 'Poppins' }}>
            {t('heroTitle')}
          </h1>

          <p className="text-base md:text-lg text-muted-foreground mb-8 max-w-lg leading-relaxed">
            {t('heroSubtext')}
          </p>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              size="lg"
              onClick={onShopNow}
              className="bg-primary hover:bg-primary/90 text-primary-foreground h-12 px-8 text-base font-semibold rounded-xl shadow-lg shadow-primary/20"
            >
              <ShoppingCart className="w-5 h-5 mr-2" />
              {t('shopNow')}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={onBecomeFarmer}
              className="h-12 px-8 text-base font-semibold rounded-xl border-2 border-primary/30 text-primary hover:bg-primary/5"
            >
              <Sprout className="w-5 h-5 mr-2" />
              {t('becomeFarmer')}
            </Button>
          </div>

          {/* Quick stats */}
          <div className="flex gap-8 mt-10 pt-8 border-t border-border/50">
            <div>
              <p className="text-2xl md:text-3xl font-bold text-primary" style={{ fontFamily: 'Poppins' }}>150+</p>
              <p className="text-xs md:text-sm text-muted-foreground">{t('farmersEmpowered')}</p>
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-secondary" style={{ fontFamily: 'Poppins' }}>100%</p>
              <p className="text-xs md:text-sm text-muted-foreground">{t('middlemenRemoved')}</p>
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-primary" style={{ fontFamily: 'Poppins' }}>+20%</p>
              <p className="text-xs md:text-sm text-muted-foreground">{t('earningsIncreased')}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
