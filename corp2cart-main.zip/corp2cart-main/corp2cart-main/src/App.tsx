import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { AppProvider } from "@/contexts/AppContext";
import LoginPage from "./pages/LoginPage";
import FarmerDashboard from "./pages/FarmerDashboard";
import FarmerProducts from "./pages/FarmerProducts";
import FarmerOrders from "./pages/FarmerOrders";
import FarmerEarnings from "./pages/FarmerEarnings";
import ConsumerBrowse from "./pages/ConsumerBrowse";
import ConsumerCart from "./pages/ConsumerCart";
import ConsumerOrders from "./pages/ConsumerOrders";
import ConsumerProfile from "./pages/ConsumerProfile";
import AdminDashboard from "./pages/AdminDashboard";
import AdminFarmers from "./pages/AdminFarmers";
import AdminProducts from "./pages/AdminProducts";
import AdminAnalytics from "./pages/AdminAnalytics";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
      <LanguageProvider>
        <AppProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<LoginPage />} />
              <Route path="/farmer" element={<FarmerDashboard />} />
              <Route path="/farmer/products" element={<FarmerProducts />} />
              <Route path="/farmer/orders" element={<FarmerOrders />} />
              <Route path="/farmer/earnings" element={<FarmerEarnings />} />
              <Route path="/consumer" element={<ConsumerBrowse />} />
              <Route path="/consumer/cart" element={<ConsumerCart />} />
              <Route path="/consumer/orders" element={<ConsumerOrders />} />
              <Route path="/consumer/profile" element={<ConsumerProfile />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/farmers" element={<AdminFarmers />} />
              <Route path="/admin/products" element={<AdminProducts />} />
              <Route path="/admin/analytics" element={<AdminAnalytics />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
          </TooltipProvider>
        </AppProvider>
      </LanguageProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
