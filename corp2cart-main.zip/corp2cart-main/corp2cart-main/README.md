# Crop2Cart Direct

Create a modern mobile application named Crop2Cart, a direct farmer-to-consumer marketplace that eliminates middlemen and ensures fair pricing and fresh delivery.

The app should support two user roles:

Farmer

Consumer

The app must be simple, multilingual, and suitable for rural and urban users.

🌍 Login Page Features:

Language selection dropdown at the top:

English

Hindi

Telugu

Tamil

Login / Register options

Role selection: Farmer or Consumer

Simple and clean UI (Green & Orange theme)

🧑‍🌾 Farmer Features:

Register with:

Name

Village/Location

Contact number

Farm type (Vegetables / Fruits / Dairy / Poultry / Grains)

Add product with:

Product name

Category

Image

Price per kg / litre / piece

Quantity available

Update stock

View and manage orders

Earnings dashboard

🛒 Consumer Features:

Browse products by categories:

Vegetables

Fruits

Grains

Dairy Products (Milk, Curd, Butter, Paneer)

Poultry Products (Eggs, Chicken)

Each product card must show:

Product image

Price

Available quantity

⭐ Farmer name

📍 Farmer location

📞 Contact option

Add to cart

Place order

Payment options (Online / Cash on Delivery)

Track order

🛠 Admin Panel:

Manage farmers and consumers

Approve product listings

Monitor transactions

View analytics

🎨 UI Requirements:

Green & Orange agricultural theme

Clean modern startup look

Easy buttons for rural users

Large readable fonts

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://corp2cart.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/e2a267fa-ec16-4085-a3bd-d3ddc933f9a7).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
